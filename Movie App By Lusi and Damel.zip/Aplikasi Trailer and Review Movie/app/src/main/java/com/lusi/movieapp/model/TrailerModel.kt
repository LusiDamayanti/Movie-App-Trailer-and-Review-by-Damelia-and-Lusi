package com.lusi.movieapp.model

data class TrailerModel (
    val key: String?,
    val name: String?
)
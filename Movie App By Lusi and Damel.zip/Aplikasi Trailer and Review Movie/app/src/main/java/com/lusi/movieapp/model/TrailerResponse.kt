package com.lusi.movieapp.model

data class TrailerResponse (
    val results: List<TrailerModel>
)
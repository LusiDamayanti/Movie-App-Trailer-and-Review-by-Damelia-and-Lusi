package com.lusi.movieapp.model

class Constant {
    companion object {
        const val API_KEY = "883420bf0ce26e9ad79d187987cf1978"
        const val BACKDROP_PATH = "https://image.tmdb.org/t/p/w500_and_h282_face"
        const val POSTER_PATH = "https://image.tmdb.org/t/p/w220_and_h330_face"

        var MOVIE_ID = 0
        var MOVIE_TITLE = ""
    }
}
package com.lusi.movieapp.model

data class GenreModel (
    val id: Int?,
    val name: String?
)